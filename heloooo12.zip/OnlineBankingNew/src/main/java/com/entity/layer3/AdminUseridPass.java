package com.entity.layer3;

public class AdminUseridPass {
	
	
	private String userid;
	
	
	private String Pass;
	
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getPass() {
		return Pass;
	}
	public void setPass(String pass) {
		Pass = pass;
	}
	

}
